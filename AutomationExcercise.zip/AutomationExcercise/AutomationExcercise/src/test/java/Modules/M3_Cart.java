package Modules;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

@Test
public class M3_Cart {

	WebDriver driver = null;
	
	public void cart(WebDriver driver) throws InterruptedException
	{
//		WebDriverManager.edgedriver().setup();
//		driver = new EdgeDriver();
//		driver.manage().window().maximize();
//		driver.get("https://automationexercise.com/login");
//
//		
//		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[1]/div[1]/form/input[2]")).sendKeys("dj2@gmail.com");
//		Thread.sleep(2000);
//		
//		driver.findElement(By.name("password")).sendKeys("Bittu1717");
//		Thread.sleep(2000);
//		
//		
//		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[1]/div[1]/form/button")).click();
//		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[3]/a")).click();
		Thread.sleep(2000);
		
//		driver.findElement(By.xpath("//*[@id=\"product-1\"]/td[6]/a/i")).click();
//		Thread.sleep(2000);
		
		
		
		driver.findElement(By.cssSelector("a.btn.btn-default.check_out")).click();
		Thread.sleep(2000);
		
		JavascriptExecutor upi =(JavascriptExecutor)driver;
		upi.executeScript("window.scrollBy(0,300)");
		Thread.sleep(2000);
		
		JavascriptExecutor u =(JavascriptExecutor)driver;
		u.executeScript("window.scrollBy(0,200)");
		Thread.sleep(2000);
		
		JavascriptExecutor p =(JavascriptExecutor)driver;
		p.executeScript("window.scrollBy(0,300)");
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//*[@id=\"ordermsg\"]/textarea")).sendKeys(" Please Deliver at next door, If no one is available ");
		Thread.sleep(2000);
		
		driver.findElement(By.linkText("Place Order")).click();
		Thread.sleep(2000);
		
		driver.navigate().back();
		
		driver.findElement(By.linkText("Place Order")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.name("name_on_card")).sendKeys("Heads High");
		Thread.sleep(2000);
		
		driver.findElement(By.name("card_number")).sendKeys("3284689162");
		Thread.sleep(2000);
		
		driver.findElement(By.name("cvc")).sendKeys("feij");
		Thread.sleep(2000);
		
		driver.findElement(By.name("expiry_month")).sendKeys("ccskv");
		Thread.sleep(2000);
		
		driver.findElement(By.name("expiry_year")).sendKeys("vewijgpw");
		Thread.sleep(2000);
		
		driver.findElement(By.id("submit")).click();
		Thread.sleep(2000);

		driver.findElement(By.linkText("Download Invoice")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.linkText("Continue")).click();
		Thread.sleep(2000);
//		driver.quit();
	
		driver.navigate().back();
		Thread.sleep(2000);
		
	}
	
	
}
