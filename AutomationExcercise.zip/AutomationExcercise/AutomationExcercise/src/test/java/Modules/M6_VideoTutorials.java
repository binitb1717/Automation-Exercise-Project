package Modules;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
@Test
public class M6_VideoTutorials {

	WebDriver driver = null;
	
	public void videoTutorials(WebDriver driver) throws InterruptedException
	{
//		WebDriverManager.edgedriver().setup();
//		driver = new EdgeDriver();
//		driver.manage().window().maximize();
//		driver.get("https://automationexercise.com/");
		
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[7]/a")).click();
		Thread.sleep(2000);
		
		driver.navigate().back();
		Thread.sleep(2000);
		
		
//		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[7]/a")).click();
//		Thread.sleep(2000);
		
		
		driver.navigate().back();
		Thread.sleep(2000);
	
		
		
	}
	
	
}
