package Modules;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

@Test
public class M4_TestCases {

	WebDriver driver = null;
	
	public void TestCases(WebDriver driver) throws InterruptedException
	{
//		WebDriverManager.edgedriver().setup();
//		driver = new EdgeDriver();
//		driver.manage().window().maximize();
//		driver.get("https://automationexercise.com/login");
		
	}	
		
		public void Break1(WebDriver driver) throws InterruptedException
		{
		
//		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[1]/div[1]/form/input[2]")).sendKeys("dj2@gmail.com");
//		Thread.sleep(2000);
//		
//		driver.findElement(By.name("password")).sendKeys("Bittu1717");
//		Thread.sleep(2000);
//		
//		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[1]/div[1]/form/button")).click();
//		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[6]/a")).click();
		Thread.sleep(2000);
		
		driver.navigate().back();
//		driver.navigate().forward();
		
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[6]/a")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[2]/div/div[1]/h4/a/u")).click();
		Thread.sleep(2000);
		JavascriptExecutor up =(JavascriptExecutor)driver;
		up.executeScript("window.scrollBy(0,500)");
		Thread.sleep(4000);
		JavascriptExecutor upi =(JavascriptExecutor)driver;
		upi.executeScript("window.scrollBy(0,500)");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[2]/div/div[1]/h4/a/u")).click();
		Thread.sleep(2000);
		
		}
		
		public void Break2(WebDriver driver) throws InterruptedException
		{
		
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[3]/div/div[1]/h4/a/u")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[3]/div/div[1]/h4/a/u")).click();
		Thread.sleep(2000);
		
		
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[4]/div/div[1]/h4/a/u")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[4]/div/div[1]/h4/a/u")).click();
		Thread.sleep(2000);
		
		
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[5]/div/div[1]/h4/a/u")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[5]/div/div[1]/h4/a/u")).click();
		Thread.sleep(2000);
		
		
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[6]/div/div[1]/h4/a/u")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[6]/div/div[1]/h4/a/u")).click();
		Thread.sleep(2000);
		
		
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[7]/div/div[1]/h4/a/u")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[7]/div/div[1]/h4/a/u")).click();
		Thread.sleep(3000);
		
		}
//		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[8]/div/div[1]/h4/a/u")).click();
//		Thread.sleep(2000);
//		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[8]/div/div[1]/h4/a/u")).click();
//		Thread.sleep(2000);
//		
//		
//		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[9]/div/div[1]/h4/a/u")).click();
//		Thread.sleep(2000);
//		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[9]/div/div[1]/h4/a/u")).click();
//		Thread.sleep(2000);
//		
//		
//		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[10]/div/div[1]/h4/a/u")).click();
//		Thread.sleep(2000);
//		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[10]/div/div[1]/h4/a/u")).click();
//		Thread.sleep(2000);
//		
//		
//		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[11]/div/div[1]/h4/a/u")).click();
//		Thread.sleep(2000);
//		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[11]/div/div[1]/h4/a/u")).click();
//		Thread.sleep(2000);
		
		public void Break3(WebDriver driver) throws InterruptedException
		{
		
		JavascriptExecutor nav =(JavascriptExecutor)driver;
		nav.executeScript("window.scrollBy(0,400)");
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[12]/div/div[1]/h4/a/u")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[12]/div/div[1]/h4/a/u")).click();
		Thread.sleep(2000);
		
		
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[13]/div/div[1]/h4/a/u")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[13]/div/div[1]/h4/a/u")).click();
		Thread.sleep(2000);
		
		
//		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[14]/div/div[1]/h4/a/u")).click();
//		Thread.sleep(2000);
//		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[14]/div/div[1]/h4/a/u")).click();
//		Thread.sleep(2000);
//		
//		
//		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[15]/div/div[1]/h4/a/u")).click();
//		Thread.sleep(2000);
//		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[15]/div/div[1]/h4/a/u")).click();
//		Thread.sleep(2000);
//		
//		
//		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[16]/div/div[1]/h4/a/u")).click();
//		Thread.sleep(2000);
//		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[16]/div/div[1]/h4/a/u")).click();
//		Thread.sleep(2000);
		
		
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[17]/div/div[1]/h4/a/u")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[17]/div/div[1]/h4/a/u")).click();
		Thread.sleep(2000);
		
		JavascriptExecutor na =(JavascriptExecutor)driver;
		na.executeScript("window.scrollBy(0,500)");
		Thread.sleep(2000);
		
		driver.navigate().back();
		
		}
		
		
		
	}

