package Modules;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

@Test
public class M2_Products {

	
WebDriver driver = null;
	
	public void Products(WebDriver driver) throws InterruptedException 
	{
//		WebDriverManager.edgedriver().setup();
//		driver = new EdgeDriver();
//		driver.manage().window().maximize();
//		driver.get("https://automationexercise.com/login");
		
//		================================ Login ===================================
		
//		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[1]/div[1]/form/input[2]")).sendKeys("dj2@gmail.com");
//		Thread.sleep(2000);
//		
//		driver.findElement(By.name("password")).sendKeys("Bittu1717");
//		Thread.sleep(2000);
//		
//		
//		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[1]/div[1]/form/button")).click();
//		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[2]/a")).click();
		Thread.sleep(5000);
		
		driver.navigate().back();
		Thread.sleep(1000);
//		
//		driver.navigate().forward();
//		Thread.sleep(1000);
		
//		driver.switchTo().alert().dismiss();
		
		JavascriptExecutor up =(JavascriptExecutor)driver;
		up.executeScript("window.scrollBy(0,300)");
		Thread.sleep(2000);
	}
//		================================ WOMEN SECTION ======================================
	
	
		public void WMen(WebDriver driver) throws InterruptedException
		{
		driver.findElement(By.xpath("//*[@id=\"accordian\"]/div[1]/div[1]/h4/a")).click();
		Thread.sleep(1000);
		
		driver.findElement(By.xpath("//*[@id=\"Women\"]/div/ul/li[2]/a")).click();
		Thread.sleep(3000);
		
		JavascriptExecutor op = (JavascriptExecutor)driver;
		op.executeScript("window.scrollBy(0,200)");
		Thread.sleep(2000);
		
		JavascriptExecutor opp = (JavascriptExecutor)driver;
		opp.executeScript("window.scrollBy(0,500)");
		Thread.sleep(3000);
		
//		================================ Move to element pending to be asked with Tejas ==================================
		
		driver.findElement(By.linkText("View Product")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("/html/body/section/div/div/div[2]/div[2]/div[2]/div/span/button")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//*[@id=\"cartModal\"]/div/div/div[3]/button")).click();
		Thread.sleep(2000);
		
		driver.navigate().back();
		Thread.sleep(2000);
		
		
		driver.findElement(By.xpath("//*[@id=\"accordian\"]/div[1]/div[1]/h4/a")).click();
		Thread.sleep(1000);
		
		driver.findElement(By.xpath("//*[@id=\"Women\"]/div/ul/li[3]/a")).click();
		Thread.sleep(3000);
		
		JavascriptExecutor p = (JavascriptExecutor)driver;
		p.executeScript("window.scrollBy(0,280)");
		Thread.sleep(2000);
		
		driver.navigate().back();
		Thread.sleep(2000);
		
		}
//		=================================== MEN SECTION =======================================
		
		
		public void men (WebDriver driver) throws InterruptedException
		{
		
		driver.findElement(By.xpath("//*[@id=\"accordian\"]/div[2]/div[1]/h4/a")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//*[@id=\"Men\"]/div/ul/li[1]/a")).click();
		Thread.sleep(2000);
		
		JavascriptExecutor Sc = (JavascriptExecutor)driver;
		Sc.executeScript("window.scrollBy(0,200)");
		Thread.sleep(2000);
		
		JavascriptExecutor Scro = (JavascriptExecutor)driver;
		Scro.executeScript("window.scrollBy(0,300)");
		Thread.sleep(2000);
		
		JavascriptExecutor Scr = (JavascriptExecutor)driver;
		Scr.executeScript("window.scrollBy(0,300)");
		Thread.sleep(2000);
		
		driver.findElement(By.cssSelector("a[data-product-id='31']")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.cssSelector("button[data-dismiss='modal']")).click();
		Thread.sleep(2000);
		
		}
//		======================================= KIDS =========================================
		
		public void kids (WebDriver driver) throws InterruptedException
		{
		
		driver.findElement(By.xpath("//*[@id=\"accordian\"]/div[3]/div[1]/h4/a")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//*[@id=\"Kids\"]/div/ul/li[1]/a")).click();
		Thread.sleep(2000);
		
		JavascriptExecutor P = (JavascriptExecutor)driver;
		P.executeScript("window.scrollBy(0,400)");
		Thread.sleep(2000);
		
		JavascriptExecutor X = (JavascriptExecutor)driver;
		X.executeScript("window.scrollBy(0,400)");
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("/html/body/section/div/div[2]/div[2]/div/div[6]/div/div[2]/ul/li/a")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.cssSelector("button[type='button']")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//*[@id=\"cartModal\"]/div/div/div[3]/button")).click();
		Thread.sleep(2000);
		
		}
		
		
		
//		driver.quit();
	
	
}

