package Modules;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

public class Login_in {
	
	WebDriver driver = null;
	
	public void Username (WebDriver driver, String username) throws InterruptedException
	{
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[4]/a")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[1]/div[1]/form/input[2]")).sendKeys(username);
		Thread.sleep(2000);
	}
	
	public void Password (WebDriver driver, String password) throws InterruptedException
	{
	
		driver.findElement(By.name("password")).sendKeys(password);
		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[1]/div[1]/form/button")).click();
		Thread.sleep(2000);
		
	}

}
