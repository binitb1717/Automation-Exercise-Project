package Modules;

import javax.xml.xpath.XPath;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

@Test
public class M5_APITesting {

	WebDriver driver = null;
	
	public void ApiTesting(WebDriver driver	) throws InterruptedException
	{
//		WebDriverManager.edgedriver().setup();
//		driver = new EdgeDriver();
//		driver.manage().window().maximize();
//		driver.get("https://automationexercise.com/");
//		
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[6]/a")).click();
		Thread.sleep(2000);
		
		driver.navigate().back();
//		driver.navigate().forward();
		
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[6]/a")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[2]/div/div[1]/h4/a/u")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[2]/div/div[1]/h4/a/u")).click();
		Thread.sleep(2000);
		
		
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[3]/div/div[1]/h4/a/u")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[3]/div/div[1]/h4/a/u")).click();
		Thread.sleep(2000);
		
		
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[4]/div/div[1]/h4/a/u")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[4]/div/div[1]/h4/a/u")).click();
		Thread.sleep(2000);
		
		
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[5]/div/div[1]/h4/a/u")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[5]/div/div[1]/h4/a/u")).click();
		Thread.sleep(2000);
		
		
		
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[6]/div/div[1]/h4/a/u")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[6]/div/div[1]/h4/a/u")).click();
		Thread.sleep(2000);
		
		
		JavascriptExecutor sun = (JavascriptExecutor)driver;
		sun.executeScript("window.scrollBy(0,500)");
		
		
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[7]/div/div[1]/h4/a/u")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[7]/div/div[1]/h4/a/u")).click();
		Thread.sleep(2000);
		
		
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[8]/div/div[1]/h4/a/u")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[8]/div/div[1]/h4/a/u")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[9]/div/div[1]/h4/a/u")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[9]/div/div[1]/h4/a/u")).click();
		Thread.sleep(2000);
		

		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[10]/div/div[1]/h4/a/u")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[10]/div/div[1]/h4/a/u")).click();
		Thread.sleep(2000);
		
		
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[11]/div/div[1]/h4/a/u")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[11]/div/div[1]/h4/a/u")).click();
		Thread.sleep(2000);
		
		
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[12]/div/div[1]/h4/a/u")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[12]/div/div[1]/h4/a/u")).click();
		Thread.sleep(2000);
		
		
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[13]/div/div[1]/h4/a/u")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[13]/div/div[1]/h4/a/u")).click();
		Thread.sleep(2000);
		
		
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[14]/div/div[1]/h4/a/u")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div[14]/div/div[1]/h4/a/u")).click();
		Thread.sleep(2000);
		
		
		driver.navigate().back();
		
	}
	
}
