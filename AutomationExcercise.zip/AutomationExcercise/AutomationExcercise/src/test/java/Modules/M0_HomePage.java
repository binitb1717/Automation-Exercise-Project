package Modules;

import java.sql.Driver;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

@Test
public class M0_HomePage {

	WebDriver driver = null;
	
	public void Home (WebDriver driver) throws InterruptedException
	{
//		WebDriverManager.edgedriver().setup();
//		driver = new EdgeDriver();
//		driver.manage().window().maximize();
//		driver.get("https://automationexercise.com/");
		
		
		driver.findElement(By.cssSelector("i.fa.fa-angle-left")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"slider-carousel\"]/div/div[3]/div[1]/a[1]/button")).click();
		Thread.sleep(2000);
		driver.navigate().back();
		
		driver.findElement(By.cssSelector("i.fa.fa-angle-left")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.cssSelector("i.fa.fa-angle-right")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.cssSelector("i.fa.fa-angle-right")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"slider-carousel\"]/div/div[1]/div[1]/a[2]/button")).click();
		Thread.sleep(2000);
		driver.navigate().back();
		
		
		JavascriptExecutor up =(JavascriptExecutor)driver;
		up.executeScript("window.scrollBy(0,500)");
		Thread.sleep(2000);
		
		JavascriptExecutor upi =(JavascriptExecutor)driver;
		upi.executeScript("window.scrollBy(0,500)");
		Thread.sleep(2000);
		
		JavascriptExecutor upid =(JavascriptExecutor)driver;
		upid.executeScript("window.scrollBy(0,500)");
		Thread.sleep(2000);
		
		JavascriptExecutor upida =(JavascriptExecutor)driver;
		upida.executeScript("window.scrollBy(0,500)");
		Thread.sleep(2000);
	
		JavascriptExecutor upiday =(JavascriptExecutor)driver;
		upiday.executeScript("window.scrollBy(0,500)");
		Thread.sleep(2000);
		
		JavascriptExecutor upide =(JavascriptExecutor)driver;
		upide.executeScript("window.scrollBy(0,600)");
		Thread.sleep(2000);
		
		JavascriptExecutor upidf =(JavascriptExecutor)driver;
		upidf.executeScript("window.scrollBy(0,600)");
		Thread.sleep(2000);
		
		JavascriptExecutor upidg =(JavascriptExecutor)driver;
		upidg.executeScript("window.scrollBy(0,600)");
		Thread.sleep(2000);
		
		JavascriptExecutor upidh =(JavascriptExecutor)driver;
		upidh.executeScript("window.scrollBy(0,600)");
		Thread.sleep(2000);
		
		JavascriptExecutor pidh =(JavascriptExecutor)driver;
		pidh.executeScript("window.scrollBy(0,600)");
		Thread.sleep(2000);
		
		JavascriptExecutor idh =(JavascriptExecutor)driver;
		idh.executeScript("window.scrollBy(0,600)");
		Thread.sleep(2000);
		
		JavascriptExecutor dh =(JavascriptExecutor)driver;
		dh.executeScript("window.scrollBy(0,600)");
		Thread.sleep(2000);
		
		JavascriptExecutor dha =(JavascriptExecutor)driver;
		dha.executeScript("window.scrollBy(0,600)");
		Thread.sleep(2000);
		
		JavascriptExecutor dhi =(JavascriptExecutor)driver;
		dhi.executeScript("window.scrollBy(0,600)");
		Thread.sleep(2000);
		
		
		
		driver.findElement(By.cssSelector("button#subscribe")).sendKeys("dodojai345@gmail.com");
		Thread.sleep(4000);
		driver.findElement(By.cssSelector("i.fa.fa-arrow-circle-o-right")).click();		
		Thread.sleep(4000);
		
		driver.quit();
		
		
	}
}
