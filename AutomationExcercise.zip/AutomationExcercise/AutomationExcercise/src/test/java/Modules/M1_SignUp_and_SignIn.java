package Modules;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;


@Test
public class M1_SignUp_and_SignIn {

	WebDriver driver = null;
	
	public void signup() throws InterruptedException 
	{
//		WebDriverManager.edgedriver().setup();
//		driver = new EdgeDriver();
//		driver.manage().window().maximize();
//		driver.get("https://automationexercise.com/");

		
////		========================================= SIGNUP ==============================================
//		
//		
//		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[4]/a")).click();
//		Thread.sleep(1000);
//		
//		driver.findElement(By.name("name")).sendKeys("Heads");
//		Thread.sleep(1000);
//		
//		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[3]/div/form/input[3]")).sendKeys("dj2@gmail.com");
//		Thread.sleep(1000);
//		
//		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[3]/div/form/button")).click();
//		Thread.sleep(2000);
//		
//		
//		
//		driver.findElement(By.id("id_gender1")).click();
//		Thread.sleep(1000);
//		
//		driver.findElement(By.id("name")).clear();
//		Thread.sleep(3000);
//		
//		driver.findElement(By.id("name")).sendKeys("Heads");
//		Thread.sleep(1000);
//		
//		driver.findElement(By.id("password")).sendKeys("Bittu1717");
//		Thread.sleep(2000);
//		
//		driver.findElement(By.id("uniform-days")).click();
//		Thread.sleep(1000);
//		driver.findElement(By.xpath("//*[@id=\"days\"]/option[11]")).click();
//		Thread.sleep(1000);
//		
//		driver.findElement(By.id("uniform-months")).click();
//		Thread.sleep(1000);
//		driver.findElement(By.xpath("//*[@id=\"months\"]/option[9]")).click();
//		Thread.sleep(1000);
//		
//		driver.findElement(By.id("uniform-years")).click();
//		Thread.sleep(1000);
//		driver.findElement(By.xpath("//*[@id=\"years\"]/option[26]")).click();
//		Thread.sleep(1000);
//		
//		driver.findElement(By.id("first_name")).sendKeys("Heads");
//		Thread.sleep(1000);
//		
//		driver.findElement(By.id("last_name")).sendKeys("High");
//		Thread.sleep(1000);
//		
//		driver.findElement(By.id("address1")).sendKeys("147/B, kailash Nagar, Dumbhal");
//		Thread.sleep(1000);
//		
//		driver.findElement(By.id("address1")).click();
//		Thread.sleep(1000);
//		driver.findElement(By.xpath("//*[@id=\"country\"]/option[1]")).click();
//		Thread.sleep(1000);
//		
//		driver.findElement(By.id("state")).sendKeys("Gujarat");
//		Thread.sleep(1000);
//		
//		driver.findElement(By.id("city")).sendKeys("Surat");
//		Thread.sleep(1000);
//		
//		driver.findElement(By.id("zipcode")).sendKeys("395162");
//		Thread.sleep(1000);
//		
//		driver.findElement(By.id("mobile_number")).sendKeys("7879348261");
//		Thread.sleep(1000);
//		
//		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div/div[1]/form/button")).click();
//		Thread.sleep(2000);
//		
//		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div/div/a")).click();
//		Thread.sleep(2000);
//		
//		driver.navigate().back();
//		Thread.sleep(1000);
//		
//		driver.navigate().forward();
//		Thread.sleep(1000);
		
		
		
//		================================ LOGIN ========================================
		
		
		
		
		
		
		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[4]/a")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[1]/div[1]/form/input[2]")).sendKeys("dj2@gmail.com");
		Thread.sleep(2000);
		
		driver.findElement(By.name("password")).sendKeys("Bittu1717");
		Thread.sleep(2000);
	
		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[1]/div[1]/form/button")).click();
		Thread.sleep(2000);
		
		String ttl = driver.getTitle();
		if (ttl.equals("Automation Exercise")) {
			System.out.println(" Test is Passed ");
		} else { System.out.println(" Test is Failed ");

		}
		
		
//		driver.quit();
		
	}
}
