package Modules;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
@Test
public class M7_Logout {

	WebDriver driver = null;
	
	public void Logout(WebDriver driver) throws InterruptedException
	{
//		WebDriverManager.edgedriver().setup();
//		driver = new EdgeDriver();
//		driver.manage().window().maximize();
//		driver.get("https://automationexercise.com/login");
//		
//		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[1]/div[1]/form/input[2]")).sendKeys("dj2@gmail.com");
//		Thread.sleep(2000);
//		
//		driver.findElement(By.name("password")).sendKeys("Bittu1717");
//		Thread.sleep(2000);
		
		
//		driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[1]/div[1]/form/button")).click();
//		Thread.sleep(2000);
		
		driver.findElement(By.xpath("/html/body/header/div/div/div/div[2]/div/ul/li[4]/a"));
		Thread.sleep(3000);
		
		
//		driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[9]/a"));
//		Thread.sleep(2000);
//		
//		driver.findElement(By.xpath("//*[@id=\"contact-us-form\"]/div[1]/input")).sendKeys("Rutvik");
//		Thread.sleep(2000);
//		
//		driver.findElement(By.name("email")).sendKeys("adkeikl@gmail.com");
//		Thread.sleep(2000);
//		
//		driver.findElement(By.name("subject")).sendKeys("Query");
//		Thread.sleep(2000);
//		
//		driver.findElement(By.name("message")).sendKeys("Hi there, Please Contact Back.. I have a Query..");
//		Thread.sleep(2000);
//		
//		driver.findElement(By.name("submit")).click();
//		Thread.sleep(2000);
//		
//		driver.switchTo().alert().accept();
//		Thread.sleep(2000);
//		
//		driver.findElement(By.xpath("//*[@id=\"form-section\"]/a/span")).click();
//		Thread.sleep(2000);
		
		
		driver.quit();
		
		
		
		
	}
	
}
