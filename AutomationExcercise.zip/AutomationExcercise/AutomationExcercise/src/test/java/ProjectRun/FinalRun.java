package ProjectRun;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import BrowserSelection.SearchEngine;
import Modules.Login_in;
import Modules.M0_HomePage;
import Modules.M1_SignUp_and_SignIn;
import Modules.M2_Products;
import Modules.M3_Cart;
import Modules.M4_TestCases;
import Modules.M5_APITesting;
import Modules.M6_VideoTutorials;
import Modules.M7_Logout;


public class FinalRun {

	WebDriver driver = null;
	M0_HomePage M0 = null;
//	M1_SignUp_and_SignIn M1 = null;
	M2_Products M2 = null;
	M3_Cart M3 = null;
	M4_TestCases M4 = null;
	M5_APITesting M5 = null;
	M6_VideoTutorials M6 = null;
	M7_Logout M7 = null;
	Login_in lp= null;
	
	
	@Test (priority = 1)
	public void BrowserSelection() throws InterruptedException
	{
		driver = new SearchEngine().Edgeselection("edge","https://automationexercise.com/" );
		Thread.sleep(2000);
//		driver.manage().window().maximize();
//		Thread.sleep(2000);
	}
	
	@Test (priority = 2)
	public void Login () throws InterruptedException 
	{
	  lp = new Login_in();
	  lp.Username(driver,"dj2@gmail.com");
	  lp.Password(driver,"Bittu1717");
	
	}
	
	@Test (priority = 3)
	public void AddProduct () throws InterruptedException 
	{
		M2 = new M2_Products();
		M2.Products(driver);
		M2.WMen(driver);
		M2.men(driver);
		M2.kids(driver);
	}
	
	@Test (priority = 4)
	public void Cart() throws InterruptedException
	{
		M3 = new M3_Cart();
		M3.cart(driver);
	}
	
	@Test (priority = 5)
	public void TestCases() throws InterruptedException
	{
		M4 = new M4_TestCases();
		M4.TestCases(driver);
		M4.Break1(driver);
		M4.Break2(driver);
		M4.Break3(driver);
	}
	
	@Test(priority = 6)
	public void ApiTesting() throws InterruptedException
	{
		M5 = new M5_APITesting();
		M5.ApiTesting(driver);
	}
	
	@Test(priority = 7)
	public void VideoTutorials() throws InterruptedException
	{
		M6 = new M6_VideoTutorials();
		M6.videoTutorials(driver);
	}
	
	public void Logout () throws InterruptedException
	{
		M7 = new M7_Logout();
		M7.Logout(driver);
	}
	
}
