package BrowserSelection;

import java.sql.Driver;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class SearchEngine
{	
	WebDriver driver = null;
	public WebDriver Edgeselection(String Browser, String Url) 
	{
		if (Browser.equals("edge")||Browser.equals("Edge")||Browser.equals("EDGE")) 
		{
//			System.setProperty("webdriver.edge.driver","F:\\Vinit\\Tops Technologies\\Automation Testing Java Selenium/msedgedriver.exe");	
			WebDriverManager.edgedriver().setup();
			driver=new EdgeDriver();
			driver.get(Url);
		}
		return driver;
	}	
	public WebDriver chromeselection(String Browser, String Url)
	{
		if (Browser.equals("chrome")||Browser.equals("Chrome")||Browser.equals("CHROME")) 
		{
//			System.setProperty("webdriver.chrome.driver","F:\\Vinit\\Tops Technologies\\Automation Testing Java Selenium/chromedriver.exe");	
			WebDriverManager.chromedriver().setup();
			driver=new ChromeDriver();
			driver.get(Url);
		}
		
		
		return driver;
	}
}
